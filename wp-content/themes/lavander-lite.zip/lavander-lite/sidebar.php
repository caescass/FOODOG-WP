<?php if(is_active_sidebar( 'lavander_sidebar' )) { ?>
	<div class="sidebar">	
		<?php dynamic_sidebar( 'lavander_sidebar' ); ?>
	</div>
<?php } ?>

